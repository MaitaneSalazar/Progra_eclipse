
public class Obstaculo {

}
